import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';

import { Shell } from '../components/Shell';
import { searchTeachers } from '../services/api';

const DEBOUNCE_MS = 300;

export function DirectorPage() {
  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');

  useEffect(() => {
    const handle = setTimeout(() => setDebouncedQuery(query.trim()), DEBOUNCE_MS);
    return () => clearTimeout(handle);
  }, [query]);

  const searchQuery = useQuery({
    queryKey: ['teacher-search', debouncedQuery],
    queryFn: () => searchTeachers(debouncedQuery),
    enabled: debouncedQuery.length > 0,
  });

  return (
    <Shell>
      <section className="page-card">
        <Link className="back-link" to="/">
          ← Home
        </Link>
        <p className="eyebrow">Day 1 · Director vertical slice</p>
        <h1>Find a teacher</h1>
        <p className="subtitle">Search the live PostgreSQL records by name or institutional acronym.</p>

        <label className="search-field">
          Search teacher
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Try Koushik, Ram, or KR"
          />
        </label>

        <div className="results-list">
          {debouncedQuery && searchQuery.isLoading && <p className="muted">Searching…</p>}
          {debouncedQuery && searchQuery.isError && (
            <p className="error-text">Search failed. Check the backend connection.</p>
          )}
          {debouncedQuery && searchQuery.isSuccess && searchQuery.data.length === 0 && (
            <p className="muted">No active teachers matched “{debouncedQuery}”.</p>
          )}
          {(searchQuery.data ?? []).map((teacher) => (
            <Link className="result-card result-card--link" key={teacher.id} to={`/director/${teacher.id}`}>
              <div>
                <h2>{teacher.name}</h2>
                <p>
                  {teacher.acronym} · {teacher.level} · {teacher.program.name} · Semester {teacher.semester}
                </p>
              </div>
              <span className="status-pill ok">View schedule</span>
            </Link>
          ))}
        </div>
      </section>
    </Shell>
  );
}
