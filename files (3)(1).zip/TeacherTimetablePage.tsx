import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';

import { DaySchedulePeriods } from '../components/DaySchedulePeriods';
import { Shell } from '../components/Shell';
import { createTimetable, getTeacher, getTimetableDay, updateTimetable } from '../services/api';
import {
  DAY_LABELS,
  DAY_NAMES,
  FALLBACK_PERIODS,
  draftEntriesToPeriods,
  periodsToEntryPayloads,
  type DayName,
  type DayPeriod,
  type EntryType,
  type ScheduleEntryPayload,
  type TimetableWritePayload,
} from '../types';

const ENTRY_TYPES: EntryType[] = ['CLASS', 'LAB', 'OTHER'];

type WeekEntries = Partial<Record<DayName, ScheduleEntryPayload[]>>;
type WeekTemplates = Partial<Record<DayName, DayPeriod[]>>;

const emptyForm = {
  entry_type: 'CLASS' as EntryType,
  subject_or_activity: '',
  section: '',
  room: '',
  notes: '',
  slot_ids: [] as string[],
};

function isNotFound(error: unknown): boolean {
  return axios.isAxiosError(error) && error.response?.status === 404;
}

function extractErrorDetail(error: unknown, fallback: string): string {
  if (axios.isAxiosError(error) && typeof error.response?.data?.detail === 'string') {
    return error.response.data.detail;
  }
  return fallback;
}

export function TeacherTimetablePage() {
  const { teacherId } = useParams<{ teacherId: string }>();
  const teacherQuery = useQuery({
    queryKey: ['teacher', teacherId],
    queryFn: () => getTeacher(teacherId!),
    enabled: Boolean(teacherId),
  });

  const [selectedDay, setSelectedDay] = useState<DayName>('monday');
  const [academicYear, setAcademicYear] = useState('');
  const [weekEntries, setWeekEntries] = useState<WeekEntries>({});
  const [weekTemplates, setWeekTemplates] = useState<WeekTemplates>({});
  const [loadState, setLoadState] = useState<'loading' | 'loaded' | 'error'>('loading');
  const [loadError, setLoadError] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [formError, setFormError] = useState<string | null>(null);
  const [saveState, setSaveState] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [saveError, setSaveError] = useState<string | null>(null);

  useEffect(() => {
    if (!teacherId) return;
    const currentTeacherId = teacherId;
    let cancelled = false;

    async function loadWeek() {
      setLoadState('loading');
      setLoadError(null);
      const entries: WeekEntries = {};
      const templates: WeekTemplates = {};

      try {
        await Promise.all(
          DAY_NAMES.map(async (day) => {
            try {
              const response = await getTimetableDay(currentTeacherId, day);
              entries[day] = periodsToEntryPayloads(response.periods);
              templates[day] = response.periods.map((period) => ({ ...period, entry: null }));
            } catch (error) {
              if (isNotFound(error)) {
                // No timetable saved yet for this teacher/day -- and ONLY
                // a 404 means that. Start this day from an empty, fixed
                // grid rather than failing the page.
                entries[day] = [];
                templates[day] = FALLBACK_PERIODS;
                return;
              }
              // Every other failure (400/409/422/500, network, timeout,
              // CORS) is a real error, not "no timetable yet" -- abort
              // the whole-week load instead of silently rendering this
              // day as empty.
              throw error;
            }
          }),
        );

        if (!cancelled) {
          setWeekEntries(entries);
          setWeekTemplates(templates);
          setLoadState('loaded');
        }
      } catch (error) {
        if (!cancelled) {
          setLoadState('error');
          setLoadError(extractErrorDetail(error, 'Could not load the current timetable from the API.'));
        }
      }
    }

    loadWeek();

    return () => {
      cancelled = true;
    };
  }, [teacherId]);

  const template = weekTemplates[selectedDay] ?? FALLBACK_PERIODS;
  const entriesForDay = weekEntries[selectedDay] ?? [];
  const previewPeriods = useMemo(() => draftEntriesToPeriods(template, entriesForDay), [template, entriesForDay]);

  const availableSlotCodes = useMemo(
    () => template.filter((period) => period.kind === 'SLOT' && period.code).map((period) => period.code as string),
    [template],
  );

  function toggleSlotCode(code: string) {
    setForm((current) => ({
      ...current,
      slot_ids: current.slot_ids.includes(code)
        ? current.slot_ids.filter((existing) => existing !== code)
        : [...current.slot_ids, code],
    }));
  }

  function handleAddEntry(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setFormError(null);

    if (!form.subject_or_activity.trim()) {
      setFormError('Subject / activity is required.');
      return;
    }
    if (form.slot_ids.length === 0) {
      setFormError('Select at least one configured slot.');
      return;
    }
    // Client-side duplicate-slot check mirrors the backend's same-payload
    // validation, so an obviously-contradictory entry is caught before a
    // round trip rather than only at save time.
    const alreadyClaimed = (weekEntries[selectedDay] ?? []).some((existing) =>
      existing.slot_ids.some((code) => form.slot_ids.includes(code)),
    );
    if (alreadyClaimed) {
      setFormError('One or more of these slots is already claimed by another entry on this day.');
      return;
    }

    const newEntry: ScheduleEntryPayload = {
      slot_ids: form.slot_ids,
      entry_type: form.entry_type,
      subject_or_activity: form.subject_or_activity.trim(),
      section: form.section.trim() || null,
      room: form.room.trim() || null,
      notes: form.notes.trim() || null,
    };

    setWeekEntries((current) => ({
      ...current,
      [selectedDay]: [...(current[selectedDay] ?? []), newEntry],
    }));
    setForm(emptyForm);
  }

  function handleRemoveEntry(indexToRemove: number) {
    setWeekEntries((current) => ({
      ...current,
      [selectedDay]: (current[selectedDay] ?? []).filter((_, index) => index !== indexToRemove),
    }));
  }

  async function handleSave() {
    if (!teacherId) return;

    if (!academicYear.trim()) {
      setSaveState('error');
      setSaveError('Academic year is required (e.g. 2025-2026).');
      return;
    }

    setSaveState('saving');
    setSaveError(null);

    const payload: TimetableWritePayload = {
      academic_year: academicYear.trim(),
      days: weekEntries,
    };

    try {
      try {
        await updateTimetable(teacherId, payload);
      } catch (error) {
        if (isNotFound(error)) {
          await createTimetable(teacherId, payload);
        } else {
          throw error;
        }
      }
      setSaveState('saved');
    } catch (error) {
      setSaveState('error');
      setSaveError(extractErrorDetail(error, 'Could not save the timetable. Please try again.'));
    }
  }

  return (
    <Shell>
      <section className="page-card">
        <Link className="back-link" to="/teacher">
          ← Teachers
        </Link>
        <div className="page-heading">
          <div>
            <p className="eyebrow">Day 1 · Timetable editor</p>
            <h1>{teacherQuery.data ? `${teacherQuery.data.name} (${teacherQuery.data.acronym})` : 'Timetable'}</h1>
            <p className="subtitle">Build the weekly draft schedule. Saving does not confirm the timetable yet.</p>
          </div>
          <span className="status-pill">DRAFT</span>
        </div>

        {teacherQuery.isError && <p className="error-text">Could not load this teacher. Check the teacher ID.</p>}

        <label className="academic-year-field">
          Academic year
          <input
            required
            value={academicYear}
            onChange={(event) => setAcademicYear(event.target.value)}
            placeholder="e.g. 2025-2026"
          />
        </label>

        <div className="day-tabs">
          {DAY_NAMES.map((day) => (
            <button
              key={day}
              type="button"
              className={`day-tab ${day === selectedDay ? 'day-tab--active' : ''}`}
              onClick={() => setSelectedDay(day)}
            >
              {DAY_LABELS[day]}
            </button>
          ))}
        </div>

        {loadState === 'loading' && <p className="muted">Loading current timetable…</p>}
        {loadState === 'error' && (
          <p className="error-text">{loadError ?? 'Could not load the current timetable from the API.'}</p>
        )}

        {loadState === 'loaded' && (
          <>
            <DaySchedulePeriods periods={previewPeriods} />

            <div className="entry-list-block">
              <h2>Entries for {DAY_LABELS[selectedDay]}</h2>
              {entriesForDay.length === 0 && <p className="muted">No entries yet for this day.</p>}
              <ul className="entry-manage-list">
                {entriesForDay.map((entry, index) => (
                  <li key={index} className="entry-manage-row">
                    <span className={`entry-type entry-type--${entry.entry_type.toLowerCase()}`}>
                      {entry.entry_type}
                    </span>
                    <span>{entry.subject_or_activity}</span>
                    <span className="muted">{entry.slot_ids.join(', ')}</span>
                    <button type="button" className="link-button" onClick={() => handleRemoveEntry(index)}>
                      Remove
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            <form className="form-grid" onSubmit={handleAddEntry}>
              <label>
                Type
                <select
                  value={form.entry_type}
                  onChange={(event) => setForm({ ...form, entry_type: event.target.value as EntryType })}
                >
                  {ENTRY_TYPES.map((type) => (
                    <option key={type} value={type}>
                      {type}
                    </option>
                  ))}
                </select>
              </label>

              <label>
                Subject / activity
                <input
                  value={form.subject_or_activity}
                  onChange={(event) => setForm({ ...form, subject_or_activity: event.target.value })}
                  placeholder="e.g. Database Management Systems"
                />
              </label>

              <label>
                Section (optional)
                <input value={form.section} onChange={(event) => setForm({ ...form, section: event.target.value })} />
              </label>

              <label>
                Room (optional)
                <input value={form.room} onChange={(event) => setForm({ ...form, room: event.target.value })} />
              </label>

              <label>
                Notes (optional)
                <input value={form.notes} onChange={(event) => setForm({ ...form, notes: event.target.value })} />
              </label>

              <div className="slot-picker">
                <span>Slots (select one, or two consecutive for a lab)</span>
                <div className="slot-picker-grid">
                  {availableSlotCodes.map((code) => (
                    <label key={code} className="slot-checkbox">
                      <input
                        type="checkbox"
                        checked={form.slot_ids.includes(code)}
                        onChange={() => toggleSlotCode(code)}
                      />
                      {code}
                    </label>
                  ))}
                </div>
              </div>

              <div className="form-actions">
                <button type="submit">Add entry to {DAY_LABELS[selectedDay]}</button>
                {formError && <p className="error-text">{formError}</p>}
              </div>
            </form>

            <div className="form-actions save-block">
              <button type="button" onClick={handleSave} disabled={saveState === 'saving' || !academicYear.trim()}>
                {saveState === 'saving' ? 'Saving…' : 'Save draft timetable'}
              </button>
              {saveState === 'saved' && <div className="success-box">Draft timetable saved.</div>}
              {saveState === 'error' && saveError && <p className="error-text">{saveError}</p>}
            </div>
          </>
        )}
      </section>
    </Shell>
  );
}
