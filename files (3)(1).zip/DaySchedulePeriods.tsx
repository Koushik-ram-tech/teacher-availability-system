import type { ReactNode } from 'react';

import { formatTimeRange, type DayPeriod } from '../types';

interface DaySchedulePeriodsProps {
  periods: DayPeriod[];
  /** Optional per-slot action (e.g. a "Remove" button in the editor). Only called for SLOT periods. */
  renderSlotActions?: (period: DayPeriod) => ReactNode;
}

export function DaySchedulePeriods({ periods, renderSlotActions }: DaySchedulePeriodsProps) {
  return (
    <ol className="period-list">
      {periods.map((period, index) => {
        if (period.kind === 'BREAK') {
          return (
            <li className="period-row period-row--break" key={`break-${index}`}>
              <span className="period-time">{formatTimeRange(period.start_time, period.end_time)}</span>
              <span className="period-label">{period.label}</span>
              <span className="period-status">Fixed break</span>
            </li>
          );
        }

        return (
          <li className="period-row" key={period.code ?? index}>
            <span className="period-time">{formatTimeRange(period.start_time, period.end_time)}</span>
            <span className="period-label">{period.code}</span>
            {period.entry ? (
              <div className="period-entry">
                <span className={`entry-type entry-type--${period.entry.entry_type.toLowerCase()}`}>
                  {period.entry.entry_type}
                </span>
                <span className="entry-subject">{period.entry.subject_or_activity}</span>
                {(period.entry.section || period.entry.room) && (
                  <span className="entry-meta">
                    {[period.entry.section, period.entry.room].filter(Boolean).join(' · ')}
                  </span>
                )}
                {period.entry.slot_codes.length > 1 && (
                  <span className="entry-meta">Spans {period.entry.slot_codes.join(', ')}</span>
                )}
              </div>
            ) : (
              <span className="period-status period-status--empty">No scheduled activity</span>
            )}
            {renderSlotActions ? <div className="period-actions">{renderSlotActions(period)}</div> : null}
          </li>
        );
      })}
    </ol>
  );
}
