import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';

import { DaySchedulePeriods } from '../components/DaySchedulePeriods';
import { Shell } from '../components/Shell';
import { getTeacher, getTimetableDay } from '../services/api';
import { DAY_LABELS, DAY_NAMES, type DayName } from '../types';

function currentDayName(): DayName {
  // Sunday (JS getDay() === 0) has no corresponding entry in DAY_NAMES,
  // since docs/TIMETABLE_RULES.md excludes it as a working day; default
  // to Monday in that case rather than showing an invalid day.
  const jsDay = new Date().getDay();
  const index = jsDay === 0 ? 0 : jsDay - 1;
  return DAY_NAMES[Math.min(index, DAY_NAMES.length - 1)];
}

export function DirectorTeacherPage() {
  const { teacherId } = useParams<{ teacherId: string }>();
  const [day, setDay] = useState<DayName>(currentDayName());
  const [academicYear, setAcademicYear] = useState('');
  const [debouncedAcademicYear, setDebouncedAcademicYear] = useState('');

  useEffect(() => {
    const trimmed = academicYear.trim();
    const handle = setTimeout(() => setDebouncedAcademicYear(trimmed), 400);
    return () => clearTimeout(handle);
  }, [academicYear]);

  const teacherQuery = useQuery({
    queryKey: ['teacher', teacherId],
    queryFn: () => getTeacher(teacherId!),
    enabled: Boolean(teacherId),
  });

  const dayQuery = useQuery({
    queryKey: ['timetable-day', teacherId, day, debouncedAcademicYear, 'CONFIRMED'],
    queryFn: () => getTimetableDay(teacherId!, day, debouncedAcademicYear, 'CONFIRMED'),
    enabled: Boolean(teacherId) && Boolean(debouncedAcademicYear),
    retry: false,
  });

  // Only a 404 means "no CONFIRMED timetable for this teacher/year yet"
  // -- a DRAFT existing for the same year does not satisfy this request.
  // Any other failure (400/409/422/500, network, timeout, CORS) is a real
  // error and must be shown as one, not silently treated as an empty
  // schedule.
  const is404 = axios.isAxiosError(dayQuery.error) && dayQuery.error.response?.status === 404;

  return (
    <Shell>
      <section className="page-card">
        <Link className="back-link" to="/director">
          ← Search
        </Link>

        <div className="page-heading">
          <div>
            <p className="eyebrow">Day 1 · Director view</p>
            <h1>{teacherQuery.data ? `${teacherQuery.data.name} (${teacherQuery.data.acronym})` : 'Teacher schedule'}</h1>
            {teacherQuery.data && (
              <p className="subtitle">
                {teacherQuery.data.level} · {teacherQuery.data.program.name} · Semester {teacherQuery.data.semester}
              </p>
            )}
          </div>
          {dayQuery.data && <span className="status-pill">{dayQuery.data.timetable_status}</span>}
        </div>

        {teacherQuery.isError && <p className="error-text">Could not load this teacher.</p>}

        <label className="academic-year-field">
          Academic year
          <input
            required
            value={academicYear}
            onChange={(event) => setAcademicYear(event.target.value)}
            placeholder="e.g. 2025-2026"
          />
        </label>

        <div className="day-tabs">
          {DAY_NAMES.map((name) => (
            <button
              key={name}
              type="button"
              className={`day-tab ${name === day ? 'day-tab--active' : ''}`}
              onClick={() => setDay(name)}
            >
              {DAY_LABELS[name]}
            </button>
          ))}
        </div>

        {!debouncedAcademicYear && (
          <p className="muted">Enter an academic year above to view this teacher's schedule for that year.</p>
        )}

        {Boolean(debouncedAcademicYear) && dayQuery.isLoading && <p className="muted">Loading schedule…</p>}

        {Boolean(debouncedAcademicYear) && dayQuery.isError && is404 && (
          <p className="muted">
            No timetable has been saved for this teacher for that academic year yet. Free-period calculation and the
            full weekly view arrive in Day 2.
          </p>
        )}

        {Boolean(debouncedAcademicYear) && dayQuery.isError && !is404 && (
          <p className="error-text">Could not load this teacher's schedule right now. Please try again.</p>
        )}

        {Boolean(debouncedAcademicYear) && dayQuery.isSuccess && <DaySchedulePeriods periods={dayQuery.data.periods} />}
      </section>
    </Shell>
  );
}
