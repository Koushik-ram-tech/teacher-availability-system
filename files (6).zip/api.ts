import axios from 'axios';

import type {
  Program,
  Teacher,
  TeacherCreatePayload,
  TimetableDayResponse,
  TimetableStatus,
  TimetableWritePayload,
  TimetableWriteResponse,
} from '../types';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8000/api/v1',
  timeout: 10_000,
});

export async function getPrograms(): Promise<Program[]> {
  const response = await api.get<Program[]>('/teachers/programs');
  return response.data;
}

export async function createTeacher(payload: TeacherCreatePayload): Promise<Teacher> {
  const response = await api.post<Teacher>('/teachers', payload);
  return response.data;
}

export async function listTeachers(): Promise<Teacher[]> {
  const response = await api.get<Teacher[]>('/teachers');
  return response.data;
}

export async function searchTeachers(query: string): Promise<Teacher[]> {
  const response = await api.get<Teacher[]>('/teachers/search', {
    params: { q: query },
  });
  return response.data;
}

export async function getTeacher(teacherId: string): Promise<Teacher> {
  const response = await api.get<Teacher>(`/teachers/${teacherId}`);
  return response.data;
}

export async function getHealth(): Promise<{ status: string; database: string }> {
  const response = await api.get<{ status: string; database: string }>('/health');
  return response.data;
}

export async function getTimetableDay(
  teacherId: string,
  day: string,
  academicYear: string,
  status: TimetableStatus,
): Promise<TimetableDayResponse> {
  const response = await api.get<TimetableDayResponse>(`/teachers/${teacherId}/timetable`, {
    params: { day, academic_year: academicYear, status },
  });
  return response.data;
}

export async function createTimetable(
  teacherId: string,
  payload: TimetableWritePayload,
): Promise<TimetableWriteResponse> {
  const response = await api.post<TimetableWriteResponse>(`/teachers/${teacherId}/timetable`, payload);
  return response.data;
}

export async function updateTimetable(
  teacherId: string,
  payload: TimetableWritePayload,
): Promise<TimetableWriteResponse> {
  const response = await api.put<TimetableWriteResponse>(`/teachers/${teacherId}/timetable`, payload);
  return response.data;
}
