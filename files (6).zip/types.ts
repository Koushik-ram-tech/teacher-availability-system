export type Level = 'UG' | 'PG';

export interface Program {
  id: string;
  name: string;
  level: Level;
  is_active: boolean;
}

export interface Teacher {
  id: string;
  name: string;
  acronym: string;
  level: Level;
  program_id: string;
  semester: number;
  department: string;
  is_active: boolean;
  program: Program;
}

export interface TeacherCreatePayload {
  name: string;
  acronym: string;
  level: Level;
  program_id: string;
  semester: number;
  department: string;
}

// ---------------------------------------------------------------------
// Timetable (Day-1 slice)
//
// academic_year is required on every write, with no server-side default.
// The UI must collect it explicitly and send it verbatim on every save.
// The same value is also required on every read: multiple draft/confirmed
// timetables can exist for a teacher across different academic years, so
// a read must state which year it means rather than relying on any
// "most recent" or "current" resolution.
// ---------------------------------------------------------------------

export type EntryType = 'CLASS' | 'LAB' | 'OTHER';

// Monday-Saturday only. Sunday is intentionally not offered anywhere in
// the UI, matching docs/TIMETABLE_RULES.md ("Sunday is not a working day
// in the prototype").
export type DayName = 'monday' | 'tuesday' | 'wednesday' | 'thursday' | 'friday' | 'saturday';

export const DAY_NAMES: DayName[] = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

export const DAY_LABELS: Record<DayName, string> = {
  monday: 'Monday',
  tuesday: 'Tuesday',
  wednesday: 'Wednesday',
  thursday: 'Thursday',
  friday: 'Friday',
  saturday: 'Saturday',
};

export type TimetableStatus = 'DRAFT' | 'CONFIRMED';

export interface ScheduleEntryPayload {
  slot_ids: string[];
  entry_type: EntryType;
  subject_or_activity: string;
  section?: string | null;
  room?: string | null;
  notes?: string | null;
}

export interface TimetableWritePayload {
  academic_year: string;
  days: Partial<Record<DayName, ScheduleEntryPayload[]>>;
}

export interface ScheduleEntryView {
  id: string;
  entry_type: EntryType;
  subject_or_activity: string;
  section?: string | null;
  room?: string | null;
  notes?: string | null;
  slot_codes: string[];
}

export interface TimetableWriteResponse {
  id: string;
  teacher_id: string;
  academic_year: string;
  status: TimetableStatus;
  source: 'MANUAL' | 'IMPORT';
  days: Partial<Record<DayName, ScheduleEntryView[]>>;
}

export interface DayPeriod {
  kind: 'SLOT' | 'BREAK';
  code?: string | null;
  label?: string | null;
  start_time: string;
  end_time: string;
  entry?: ScheduleEntryView | null;
}

export interface TimetableDayResponse {
  teacher_id: string;
  academic_year: string;
  day: DayName;
  timetable_status: TimetableStatus;
  periods: DayPeriod[];
}

// Client-side fallback grid, used only when a teacher has no saved
// timetable yet (GET .../timetable correctly returns 404 in that case, so
// there is no server response to render slot/break structure from).
// Actual slot codes/times always come from the backend once any draft
// exists; this is purely scaffolding so a brand-new teacher can start
// building their first draft from an empty grid instead of a blank screen.
export const FALLBACK_PERIODS: DayPeriod[] = [
  { kind: 'SLOT', code: 'S1', start_time: '08:00:00', end_time: '08:55:00', entry: null },
  { kind: 'SLOT', code: 'S2', start_time: '08:55:00', end_time: '09:50:00', entry: null },
  { kind: 'SLOT', code: 'S3', start_time: '09:50:00', end_time: '10:45:00', entry: null },
  { kind: 'BREAK', label: 'Morning break', start_time: '10:45:00', end_time: '11:15:00', entry: null },
  { kind: 'SLOT', code: 'S4', start_time: '11:15:00', end_time: '12:10:00', entry: null },
  { kind: 'SLOT', code: 'S5', start_time: '12:10:00', end_time: '13:05:00', entry: null },
  { kind: 'BREAK', label: 'Lunch', start_time: '13:05:00', end_time: '14:00:00', entry: null },
  { kind: 'SLOT', code: 'S6', start_time: '14:00:00', end_time: '14:55:00', entry: null },
  { kind: 'SLOT', code: 'S7', start_time: '14:55:00', end_time: '15:50:00', entry: null },
  { kind: 'SLOT', code: 'S8', start_time: '15:50:00', end_time: '16:45:00', entry: null },
  { kind: 'SLOT', code: 'S9', start_time: '16:45:00', end_time: '17:40:00', entry: null },
];

export function formatTimeRange(start: string, end: string): string {
  return `${start.slice(0, 5)}–${end.slice(0, 5)}`;
}

/** Collapses a day's periods into the entry payload shape the write API
 * expects, merging a multi-slot entry (e.g. a lab spanning two periods)
 * back into a single entry with combined slot_ids instead of duplicating
 * it once per slot. */
export function periodsToEntryPayloads(periods: DayPeriod[]): ScheduleEntryPayload[] {
  const byEntryId = new Map<string, ScheduleEntryPayload>();
  for (const period of periods) {
    if (period.kind !== 'SLOT' || !period.entry || !period.code) continue;
    const existing = byEntryId.get(period.entry.id);
    if (existing) {
      existing.slot_ids.push(period.code);
    } else {
      byEntryId.set(period.entry.id, {
        slot_ids: [period.code],
        entry_type: period.entry.entry_type,
        subject_or_activity: period.entry.subject_or_activity,
        section: period.entry.section,
        room: period.entry.room,
        notes: period.entry.notes,
      });
    }
  }
  return Array.from(byEntryId.values());
}

/** Rebuilds a day's period grid (slot/break structure + times, taken from
 * an already-fetched template) with a fresh set of entries laid on top. */
export function applyEntriesToPeriods(templatePeriods: DayPeriod[], entries: ScheduleEntryView[]): DayPeriod[] {
  const entryByCode = new Map<string, ScheduleEntryView>();
  for (const entry of entries) {
    for (const code of entry.slot_codes) {
      entryByCode.set(code, entry);
    }
  }
  return templatePeriods.map((period) => {
    if (period.kind !== 'SLOT' || !period.code) return { ...period, entry: null };
    return { ...period, entry: entryByCode.get(period.code) ?? null };
  });
}

/** Same idea as applyEntriesToPeriods, but for not-yet-saved draft entries
 * (ScheduleEntryPayload has no id yet). Synthesizes a display-only id
 * purely so the shared DaySchedulePeriods component has something to
 * key/group on while editing. */
export function draftEntriesToPeriods(templatePeriods: DayPeriod[], entries: ScheduleEntryPayload[]): DayPeriod[] {
  const entryByCode = new Map<string, ScheduleEntryView & { __draftIndex: number }>();
  entries.forEach((entry, draftIndex) => {
    const view: ScheduleEntryView & { __draftIndex: number } = {
      id: `draft-${draftIndex}`,
      entry_type: entry.entry_type,
      subject_or_activity: entry.subject_or_activity,
      section: entry.section,
      room: entry.room,
      notes: entry.notes,
      slot_codes: entry.slot_ids,
      __draftIndex: draftIndex,
    };
    for (const code of entry.slot_ids) {
      entryByCode.set(code, view);
    }
  });
  return templatePeriods.map((period) => {
    if (period.kind !== 'SLOT' || !period.code) return { ...period, entry: null };
    return { ...period, entry: entryByCode.get(period.code) ?? null };
  });
}
